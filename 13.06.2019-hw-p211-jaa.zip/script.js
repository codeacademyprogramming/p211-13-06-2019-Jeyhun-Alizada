"use strict";
const fruitsSrc = [
  "f1.png",
  "f2.png",
  "f3.png",
  "f4.png",
  "f5.png",
  "f6.png",
  "f7.png",
  "f8.png",
  "f9.png",
  "f10.png"
];
const trashZone = document.getElementById("trashZone");
const fruitZone = document.getElementById("fruitZone");
const scoreZone = document.getElementById("scoreZone");
const scoreHolder = scoreZone.querySelector("span");
const start = document.getElementById("start");
const end = document.getElementById("end");
start.onclick = () => {
  craeterInterval = setInterval(() => {
    fruitCraeter();
  }, 3000);
};
end.onclick = () => {
  clearInterval(craeterInterval);
};
let fruitHolder;
// let timerInterval;
let craeterInterval;
let topMoverInterval;
// let secondPassed = 0;

// let draggedElement;
// let hasGameStarted = false;

function fruitCraeter() {
  fruitHolder = document.createElement("span");
  fruitHolder.classList.add("fruitHolder");
  fruitHolder.setAttribute("draggable", true);
  fruitHolder.style.left = Math.round(Math.random() * 80) + "%";
  const fruit = document.createElement("img");
  const randomFruit = GenerateRandomNumber(0, fruitsSrc.length - 1);
  fruit.setAttribute("src", fruitsSrc[randomFruit]);
  fruitHolder.appendChild(fruit);
  fruitZone.appendChild(fruitHolder);
  // let moveringFruitHolder = [];
  // moveringFruitHolder.push(fruitHolder);
  // console.log(moveringFruitHolder);
  let newTop = 0;
  topMoverInterval = setInterval(mover, 10);
  function mover() {
    if (newTop == 450) {
      clearInterval(fruitCraeter);
      // fruitHolder.remove();
    } else {
      newTop++;
      fruitHolder.style.top = newTop + "px";
    }
  }
}
trashZone.ondragover = function(e) {
  e.preventDefault();
};
let score = 0;
trashZone.ondrop = function() {
  trashZone.appendChild(fruitHolder);
  const audio = new Audio("burger.wav");
  audio.play();
  score++;
  scoreHolder.innerText = score;
};

// let trashFruit = document.querySelectorAll("#trashZone .fruitHolder");
// function remover() {
//   trashFruit.forEach(element => {
//     element.remove();
//   });
// }

// let removerSetInterval = setInterval(remover(), 6000);
// let trashFruit = document.querySelectorAll("#trashZone .fruitHolder");
// trashFruit.onclick = () => alert("ok")

function GenerateRandomNumber(min, max) {
  return Math.round(min + Math.random() * (max - min));
}
